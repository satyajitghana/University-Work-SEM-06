#!/bin/bash

# install the dependecies before building
sudo sh install_deps.sh

# build
make